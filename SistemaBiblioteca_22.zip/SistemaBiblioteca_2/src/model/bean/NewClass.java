/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Guilherme Freire
 */
public class NewClass {
    private long matr_bib;

    public long getMatr_bib() {
        return matr_bib;
    }

    public void setMatr_bib(long matr_bib) {
        this.matr_bib = matr_bib;
    }
    
}
