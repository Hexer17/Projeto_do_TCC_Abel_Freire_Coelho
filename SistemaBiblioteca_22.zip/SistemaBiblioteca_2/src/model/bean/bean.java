/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

public class bean {
    public String usar;
    public String senha;

    public String getUsar() {
        return usar;
    }

    public void setUsar(String usar) {
        this.usar = usar;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
}
